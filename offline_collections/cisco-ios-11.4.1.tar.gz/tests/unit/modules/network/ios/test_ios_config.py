#
# (c) 2016 Red Hat Inc.
#
# This file is part of Ansible
#
# Ansible is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Ansible is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with Ansible.  If not, see <http://www.gnu.org/licenses/>.

# Make coding more python3-ish
from __future__ import absolute_import, division, print_function


__metaclass__ = type
from unittest.mock import MagicMock, patch

from ansible_collections.cisco.ios.plugins.cliconf.ios import Cliconf
from ansible_collections.cisco.ios.plugins.modules import ios_config
from ansible_collections.cisco.ios.tests.unit.modules.utils import set_module_args

from .ios_module import TestIosModule, load_fixture


class TestIosConfigModule(TestIosModule):
    module = ios_config

    def setUp(self):
        super(TestIosConfigModule, self).setUp()

        self.mock_get_config = patch(
            "ansible_collections.cisco.ios.plugins.modules.ios_config.get_config",
        )
        self.get_config = self.mock_get_config.start()

        self.mock_get_connection = patch(
            "ansible_collections.cisco.ios.plugins.modules.ios_config.get_connection",
        )
        self.get_connection = self.mock_get_connection.start()

        self.conn = self.get_connection()
        self.conn.edit_config = MagicMock()

        self.mock_run_commands = patch(
            "ansible_collections.cisco.ios.plugins.modules.ios_config.run_commands",
        )
        self.run_commands = self.mock_run_commands.start()

        self.cliconf_obj = Cliconf(MagicMock())
        self.running_config = load_fixture("ios_config_config.cfg")

    def tearDown(self):
        super(TestIosConfigModule, self).tearDown()
        self.mock_get_config.stop()
        self.mock_run_commands.stop()
        self.mock_get_connection.stop()

    def load_fixtures(self, commands=None):
        config_file = "ios_config_config.cfg"
        self.get_config.return_value = load_fixture(config_file)
        self.get_connection.edit_config.return_value = None

    def test_ios_config_unchanged(self):
        src = load_fixture("ios_config_config.cfg")
        self.conn.get_diff = MagicMock(return_value=self.cliconf_obj.get_diff(src, src))
        set_module_args(dict(src=src))
        self.execute_module()

    def test_ios_config_src(self):
        src = load_fixture("ios_config_src.cfg")
        set_module_args(dict(src=src))
        self.conn.get_diff = MagicMock(
            return_value=self.cliconf_obj.get_diff(src, self.running_config),
        )
        commands = ["hostname foo", "interface GigabitEthernet0/0", "no ip address"]
        self.execute_module(changed=True, commands=commands)

    def test_ios_config_content(self):
        content = "interface Loopback998\n shutdown"
        set_module_args(dict(content=content))
        self.conn.get_diff = MagicMock(
            return_value=self.cliconf_obj.get_diff(content, self.running_config),
        )
        commands = ["interface Loopback998", "shutdown"]
        self.execute_module(changed=True, commands=commands, sort=False)
        self.assertEqual(self.conn.edit_config.call_count, 1)

    def test_ios_config_backup(self):
        set_module_args(dict(backup=True))
        result = self.execute_module()
        self.assertIn("__backup__", result)

    def test_ios_config_save_changed_true(self):
        src = load_fixture("ios_config_src.cfg")
        set_module_args(dict(src=src, save_when="changed"))
        commands = ["hostname foo", "interface GigabitEthernet0/0", "no ip address"]
        self.conn.get_diff = MagicMock(
            return_value=self.cliconf_obj.get_diff(src, self.running_config),
        )
        self.execute_module(changed=True, commands=commands)
        self.assertEqual(self.run_commands.call_count, 1)
        self.assertEqual(self.get_config.call_count, 1)
        self.assertEqual(self.conn.edit_config.call_count, 1)
        args = self.run_commands.call_args[0][1]
        self.assertIn("copy running-config startup-config\r", args)

    def test_ios_config_save_changed_false(self):
        set_module_args(dict(save_when="changed"))
        self.execute_module(changed=False)
        self.assertEqual(self.run_commands.call_count, 0)
        self.assertEqual(self.get_config.call_count, 0)
        self.assertEqual(self.conn.edit_config.call_count, 0)

    def test_ios_config_save_always(self):
        self.run_commands.return_value = "hostname foo"
        set_module_args(dict(save_when="always"))
        self.execute_module(changed=True)
        self.assertEqual(self.run_commands.call_count, 1)
        self.assertEqual(self.get_config.call_count, 0)
        self.assertEqual(self.conn.edit_config.call_count, 0)
        args = self.run_commands.call_args[0][1]
        self.assertIn("copy running-config startup-config\r", args)

    def test_ios_config_lines_wo_parents(self):
        lines = ["hostname foo"]
        set_module_args(dict(lines=lines))
        self.conn.get_diff = MagicMock(
            return_value=self.cliconf_obj.get_diff(
                "\n".join(lines),
                self.running_config,
            ),
        )
        commands = ["hostname foo"]
        self.execute_module(changed=True, commands=commands)

    def test_ios_config_lines_w_parents(self):
        lines = ["shutdown"]
        parents = ["interface GigabitEthernet0/0"]
        set_module_args(dict(lines=lines, parents=parents))
        module = MagicMock()
        module.params = {"lines": lines, "parents": parents, "src": None, "content": None}
        candidate_config = ios_config.get_candidate_config(module)

        self.conn.get_diff = MagicMock(
            return_value=self.cliconf_obj.get_diff(
                candidate_config,
                self.running_config,
            ),
        )

        commands = ["interface GigabitEthernet0/0", "shutdown"]
        self.execute_module(changed=True, commands=commands)

    def test_ios_config_before(self):
        lines = ["hostname foo"]
        set_module_args(dict(lines=lines, before=["test1", "test2"]))
        self.conn.get_diff = MagicMock(
            return_value=self.cliconf_obj.get_diff(
                "\n".join(lines),
                self.running_config,
            ),
        )
        commands = ["test1", "test2", "hostname foo"]
        self.execute_module(changed=True, commands=commands, sort=False)

    def test_ios_config_after(self):
        lines = ["hostname foo"]
        set_module_args(dict(lines=lines, after=["test1", "test2"]))
        self.conn.get_diff = MagicMock(
            return_value=self.cliconf_obj.get_diff(
                "\n".join(lines),
                self.running_config,
            ),
        )
        commands = ["hostname foo", "test1", "test2"]
        self.execute_module(changed=True, commands=commands, sort=False)

    def test_ios_config_before_after_no_change(self):
        lines = ["hostname router"]
        set_module_args(
            dict(lines=lines, before=["test1", "test2"], after=["test3", "test4"]),
        )
        self.conn.get_diff = MagicMock(
            return_value=self.cliconf_obj.get_diff(
                "\n".join(lines),
                self.running_config,
            ),
        )
        self.execute_module()

    def test_ios_config_config(self):
        config = "hostname localhost"
        lines = ["hostname router"]
        set_module_args(dict(lines=lines, config=config))
        self.conn.get_diff = MagicMock(
            return_value=self.cliconf_obj.get_diff("\n".join(lines), config),
        )
        commands = ["hostname router"]
        self.execute_module(changed=True, commands=commands)

    def test_ios_config_prompt(self):
        lines = [
            {
                "config_line": "access-session accounting attributes filter-spec include list myVLANList",
                "prompt": "Do you wish to continue\\? \\[yes]:",
                "answer": "yes",
            },
        ]
        set_module_args(dict(lines=lines, save_when="changed"))
        module = MagicMock()
        module.params = {"lines": lines, "src": None, "parents": None, "content": None}
        candidate_config = ios_config.get_candidate_config(module)

        self.conn.get_diff = MagicMock(
            return_value=self.cliconf_obj.get_diff(
                candidate_config,
                self.running_config,
            ),
        )

        commands = ["access-session accounting attributes filter-spec include list myVLANList"]
        self.execute_module(changed=True, commands=commands)

    def test_ios_config_replace_block(self):
        lines = ["description test string", "test string"]
        parents = ["interface GigabitEthernet0/0"]
        set_module_args(dict(lines=lines, replace="block", parents=parents))

        module = MagicMock()
        module.params = {
            "lines": lines,
            "parents": parents,
            "src": None,
            "before": None,
            "content": None,
        }
        candidate_config = ios_config.get_candidate_config(module)

        self.conn.get_diff = MagicMock(
            return_value=self.cliconf_obj.get_diff(
                candidate_config,
                self.running_config,
                diff_replace="block",
                path=parents,
            ),
        )

        commands = parents + lines
        self.execute_module(changed=True, commands=commands)

    def test_ios_config_replace_block_src(self):
        src = load_fixture("ios_config_src.cfg")
        set_module_args(dict(src=src, replace="block"))
        self.conn.get_diff = MagicMock(
            return_value=self.cliconf_obj.get_diff(src, self.running_config),
        )
        commands = ["hostname foo", "interface GigabitEthernet0/0", "no ip address"]
        self.execute_module(changed=True, commands=commands)

    def test_ios_config_match_none(self):
        lines = ["hostname router"]
        set_module_args(dict(lines=lines, match="none"))
        self.conn.get_diff = MagicMock(
            return_value=self.cliconf_obj.get_diff(
                "\n".join(lines),
                self.running_config,
                diff_match="none",
            ),
        )
        self.execute_module(changed=True, commands=lines)

    def test_ios_config_match_none2(self):
        lines = ["ip address 1.2.3.4 255.255.255.0", "description test string"]
        parents = ["interface GigabitEthernet0/0"]
        set_module_args(dict(lines=lines, parents=parents, match="none"))

        module = MagicMock()
        module.params = {"lines": lines, "parents": parents, "src": None, "content": None}
        candidate_config = ios_config.get_candidate_config(module)
        self.conn.get_diff = MagicMock(
            return_value=self.cliconf_obj.get_diff(
                candidate_config,
                self.running_config,
                diff_match="none",
                path=parents,
            ),
        )

        commands = parents + lines
        self.execute_module(changed=True, commands=commands, sort=False)

    def test_ios_config_match_strict(self):
        lines = [
            "ip address 1.2.3.4 255.255.255.0",
            "description test string",
            "shutdown",
        ]
        parents = ["interface GigabitEthernet0/0"]
        set_module_args(dict(lines=lines, parents=parents, match="strict"))

        module = MagicMock()
        module.params = {"lines": lines, "parents": parents, "src": None, "content": None}
        candidate_config = ios_config.get_candidate_config(module)
        self.conn.get_diff = MagicMock(
            return_value=self.cliconf_obj.get_diff(
                candidate_config,
                self.running_config,
                diff_match="strict",
                path=parents,
            ),
        )

        commands = parents + ["shutdown"]
        self.execute_module(changed=True, commands=commands, sort=False)

    def test_ios_config_match_exact(self):
        lines = [
            "ip address 1.2.3.4 255.255.255.0",
            "description test string",
            "shutdown",
        ]
        parents = ["interface GigabitEthernet0/0"]
        set_module_args(dict(lines=lines, parents=parents, match="exact"))

        module = MagicMock()
        module.params = {"lines": lines, "parents": parents, "src": None, "content": None}
        candidate_config = ios_config.get_candidate_config(module)
        self.conn.get_diff = MagicMock(
            return_value=self.cliconf_obj.get_diff(
                candidate_config,
                self.running_config,
                diff_match="exact",
                path=parents,
            ),
        )

        commands = parents + lines
        self.execute_module(changed=True, commands=commands, sort=False)

    def test_ios_config_interface_range_parents_idempotent(self):
        lines = ["description test string"]
        parents = "interface range GigabitEthernet 0/0, GigabitEthernet 0/1"
        set_module_args(dict(lines=lines, parents=parents))
        self.conn.get_diff = MagicMock(side_effect=self.cliconf_obj.get_diff)

        self.execute_module(changed=False)
        get_diff_call = self.conn.get_diff.call_args.kwargs
        self.assertEqual(
            get_diff_call["path"],
            ["interface range GigabitEthernet 0/0, GigabitEthernet 0/1"],
        )

    def test_ios_config_interface_range_parents_executes_range_command(self):
        lines = ["shutdown"]
        parents = "interface range GigabitEthernet 0/0, GigabitEthernet 0/1"
        set_module_args(dict(lines=lines, parents=parents))
        self.conn.get_diff = MagicMock(side_effect=self.cliconf_obj.get_diff)

        commands = ["interface range GigabitEthernet 0/0, GigabitEthernet 0/1", "shutdown"]
        self.execute_module(changed=True, commands=commands, sort=False)

    def test_ios_config_src_and_lines_fails(self):
        args = dict(src="foo", lines="foo")
        set_module_args(args)
        self.execute_module(failed=True)

    def test_ios_config_src_and_parents_fails(self):
        args = dict(src="foo", parents="foo")
        set_module_args(args)
        self.execute_module(failed=True)

    def test_ios_config_match_exact_requires_lines(self):
        args = dict(match="exact")
        set_module_args(args)
        self.execute_module(failed=True)

    def test_ios_config_match_strict_requires_lines(self):
        args = dict(match="strict")
        set_module_args(args)
        self.execute_module(failed=True)

    def test_ios_config_replace_block_requires_lines(self):
        args = dict(replace="block")
        set_module_args(args)
        self.execute_module(failed=True)

    def test_ios_config_replace_config_requires_src(self):
        args = dict(replace="config")
        set_module_args(args)
        self.execute_module(failed=True)

    def test_normalize_parents_merges_multiline_interface_range(self):
        parents = [
            "interface range GigabitEthernet 0/0",
            "GigabitEthernet 0/1",
        ]
        self.assertEqual(
            ios_config.normalize_parents(parents),
            ["interface range GigabitEthernet 0/0, GigabitEthernet 0/1"],
        )

    def test_normalize_parents_single_parent_unchanged(self):
        p = ["interface range GigabitEthernet 0/0"]
        self.assertEqual(ios_config.normalize_parents(p), p)

    def test_expand_interface_range_parent_comma_separated(self):
        self.assertEqual(
            ios_config.expand_interface_range_parent(
                "interface range GigabitEthernet 0/0, GigabitEthernet 0/1",
            ),
            [
                "interface GigabitEthernet0/0",
                "interface GigabitEthernet0/1",
            ],
        )

    def test_expand_interface_range_parent_numeric_span(self):
        self.assertEqual(
            ios_config.expand_interface_range_parent(
                "interface range GigabitEthernet 0/0 - 0/2",
            ),
            [
                "interface GigabitEthernet0/0",
                "interface GigabitEthernet0/1",
                "interface GigabitEthernet0/2",
            ],
        )

    def test_expand_interface_range_parent_not_range_returns_empty(self):
        self.assertEqual(
            ios_config.expand_interface_range_parent("interface GigabitEthernet0/0"),
            [],
        )

    def test_expand_interface_range_parent_invalid_token_returns_empty(self):
        self.assertEqual(
            ios_config.expand_interface_range_parent("interface range FooBar"),
            [],
        )

    def test_expand_interface_range_prefix_mismatch_returns_empty(self):
        self.assertEqual(
            ios_config.expand_interface_range_parent(
                "interface range GigabitEthernet 0/0 - Ethernet0/2",
            ),
            [],
        )

    def test_build_expanded_range_candidate(self):
        raw = ios_config.build_expanded_range_candidate(
            ["interface GigabitEthernet0/0", "interface GigabitEthernet0/1"],
            [" description x"],
        )
        self.assertIn("interface GigabitEthernet0/0", raw)
        self.assertIn("description x", raw)
