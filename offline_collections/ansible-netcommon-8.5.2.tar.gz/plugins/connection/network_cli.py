# (c) 2016 Red Hat Inc.
# (c) 2017 Ansible Project
# GNU General Public License v3.0+ (see LICENSES/GPL-3.0-or-later.txt or https://www.gnu.org/licenses/gpl-3.0.txt)
# SPDX-License-Identifier: GPL-3.0-or-later

from __future__ import absolute_import, division, print_function


__metaclass__ = type

DOCUMENTATION = """
author:
 - Ansible Networking Team (@ansible-network)
name: network_cli
short_description: Use network_cli to run command on network appliances
description:
- This connection plugin provides a connection to remote devices over the SSH and
  implements a CLI shell.  This connection plugin is typically used by network devices
  for sending and receiving CLi commands to network devices.
version_added: 1.0.0
requirements:
- ansible-pylibssh if using I(ssh_type=libssh)
extends_documentation_fragment:
- ansible.netcommon.connection_persistent
options:
  host:
    description:
    - Specifies the remote device FQDN or IP address to establish the SSH connection
      to.
    default: inventory_hostname
    type: string
    vars:
    - name: inventory_hostname
    - name: ansible_host
  port:
    type: int
    description:
    - Specifies the port on the remote device that listens for connections when establishing
      the SSH connection.
    default: 22
    ini:
    - section: defaults
      key: remote_port
    env:
    - name: ANSIBLE_REMOTE_PORT
    vars:
    - name: ansible_port
  network_os:
    description:
    - Configures the device platform network operating system.  This value is used
      to load the correct terminal and cliconf plugins to communicate with the remote
      device.
    type: string
    vars:
    - name: ansible_network_os
  remote_user:
    description:
    - The username used to authenticate to the remote device when the SSH connection
      is first established.  If the remote_user is not specified, the connection will
      use the username of the logged in user.
    - Can be configured from the CLI via the C(--user) or C(-u) options.
    type: string
    ini:
    - section: defaults
      key: remote_user
    env:
    - name: ANSIBLE_REMOTE_USER
    vars:
    - name: ansible_user
  password:
    description:
    - Configures the user password used to authenticate to the remote device when
      first establishing the SSH connection.
    type: string
    vars:
    - name: ansible_password
    - name: ansible_ssh_pass
    - name: ansible_ssh_password
  private_key_file:
    description:
    - The private SSH key or certificate file used to authenticate to the remote device
      when first establishing the SSH connection.
    type: string
    ini:
    - section: defaults
      key: private_key_file
    env:
    - name: ANSIBLE_PRIVATE_KEY_FILE
    vars:
    - name: ansible_private_key_file
  become:
    type: boolean
    description:
    - The become option will instruct the CLI session to attempt privilege escalation
      on platforms that support it.  Normally this means transitioning from user mode
      to C(enable) mode in the CLI session. If become is set to True and the remote
      device does not support privilege escalation or the privilege has already been
      elevated, then this option is silently ignored.
    - Can be configured from the CLI via the C(--become) or C(-b) options.
    default: false
    ini:
    - section: privilege_escalation
      key: become
    env:
    - name: ANSIBLE_BECOME
    vars:
    - name: ansible_become
  become_errors:
    type: str
    description:
    - This option determines how privilege escalation failures are handled when
      I(become) is enabled.
    - When set to C(ignore), the errors are silently ignored.
      When set to C(warn), a warning message is displayed.
      The default option C(fail), triggers a failure and halts execution.
    vars:
    - name: ansible_network_become_errors
    default: fail
    choices: ["ignore", "warn", "fail"]
  terminal_errors:
    type: str
    description:
    - This option determines how failures while setting terminal parameters
      are handled.
    - When set to C(ignore), the errors are silently ignored.
      When set to C(warn), a warning message is displayed.
      The default option C(fail), triggers a failure and halts execution.
    vars:
    - name: ansible_network_terminal_errors
    default: fail
    choices: ["ignore", "warn", "fail"]
    version_added: 3.1.0
  become_method:
    description:
    - This option allows the become method to be specified in for handling privilege
      escalation.  Typically the become_method value is set to C(enable) but could
      be defined as other values.
    default: sudo
    type: string
    ini:
    - section: privilege_escalation
      key: become_method
    env:
    - name: ANSIBLE_BECOME_METHOD
    vars:
    - name: ansible_become_method
  host_key_auto_add:
    type: boolean
    description:
    - When C(true), unknown host keys are automatically added to the user known_hosts
      file and saved on connection close, so the first connection to a new host works
      without manual intervention (e.g. no need to run ssh-keyscan or set config).
    - When C(false), Ansible would prompt before adding; since network_cli uses
      persistent connections (background processes), the user cannot respond, so
      connection fails for new hosts unless the key is already in known_hosts.
    - Set to C(false) if you need to avoid automatically trusting new host keys
      (e.g. on production systems where you manage known_hosts separately).
    default: true
    ini:
    - section: paramiko_connection
      key: host_key_auto_add
    env:
    - name: ANSIBLE_HOST_KEY_AUTO_ADD
  persistent_buffer_read_timeout:
    type: float
    description:
    - Configures, in seconds, the amount of time to wait for the data to be read from
      Paramiko channel after the command prompt is matched. This timeout value ensures
      that command prompt matched is correct and there is no more data left to be
      received from remote host.
    default: 0.1
    ini:
    - section: persistent_connection
      key: buffer_read_timeout
    env:
    - name: ANSIBLE_PERSISTENT_BUFFER_READ_TIMEOUT
    vars:
    - name: ansible_buffer_read_timeout
  terminal_stdout_re:
    type: list
    elements: dict
    description:
    - A single regex pattern or a sequence of patterns along with optional flags to
      match the command prompt from the received response chunk. This option accepts
      C(pattern) and C(flags) keys. The value of C(pattern) is a python regex pattern
      to match the response and the value of C(flags) is the value accepted by I(flags)
      argument of I(re.compile) python method to control the way regex is matched
      with the response, for example I('re.I').
    vars:
    - name: ansible_terminal_stdout_re
  terminal_stderr_re:
    type: list
    elements: dict
    description:
    - This option provides the regex pattern and optional flags to match the error
      string from the received response chunk. This option accepts C(pattern) and
      C(flags) keys. The value of C(pattern) is a python regex pattern to match the
      response and the value of C(flags) is the value accepted by I(flags) argument
      of I(re.compile) python method to control the way regex is matched with the
      response, for example I('re.I').
    vars:
    - name: ansible_terminal_stderr_re
  terminal_initial_prompt:
    type: list
    elements: string
    description:
    - A single regex pattern or a sequence of patterns to evaluate the expected prompt
      at the time of initial login to the remote host.
    vars:
    - name: ansible_terminal_initial_prompt
  terminal_initial_answer:
    type: list
    elements: string
    description:
    - The answer to reply with if the C(terminal_initial_prompt) is matched. The value
      can be a single answer or a list of answers for multiple terminal_initial_prompt.
      In case the login menu has multiple prompts the sequence of the prompt and excepted
      answer should be in same order and the value of I(terminal_prompt_checkall)
      should be set to I(True) if all the values in C(terminal_initial_prompt) are
      expected to be matched and set to I(False) if any one login prompt is to be
      matched.
    vars:
    - name: ansible_terminal_initial_answer
  terminal_initial_prompt_checkall:
    type: boolean
    description:
    - By default the value is set to I(False) and any one of the prompts mentioned
      in C(terminal_initial_prompt) option is matched it won't check for other prompts.
      When set to I(True) it will check for all the prompts mentioned in C(terminal_initial_prompt)
      option in the given order and all the prompts should be received from remote
      host if not it will result in timeout.
    default: false
    vars:
    - name: ansible_terminal_initial_prompt_checkall
  terminal_inital_prompt_newline:
    type: boolean
    description:
    - This boolean flag, that when set to I(True) will send newline in the response
      if any of values in I(terminal_initial_prompt) is matched.
    default: true
    vars:
    - name: ansible_terminal_initial_prompt_newline
  network_cli_retries:
    description:
    - Number of attempts to connect to remote host. The delay time between the retires
      increases after every attempt by power of 2 in seconds till either the maximum
      attempts are exhausted or any of the C(persistent_command_timeout) or C(persistent_connect_timeout)
      timers are triggered.
    default: 3
    type: integer
    env:
    - name: ANSIBLE_NETWORK_CLI_RETRIES
    ini:
    - section: persistent_connection
      key: network_cli_retries
    vars:
    - name: ansible_network_cli_retries
  ssh_type:
    description:
      - The python package that will be used by the C(network_cli) connection plugin to create a SSH connection to remote host.
      - I(libssh) will use the ansible-pylibssh package, which needs to be installed in order to work.
      - I(paramiko) will instead use the paramiko package to manage the SSH connection.
        This option is deprecated and will be removed in a release after 2028-02-01.
        Migrate to I(libssh) by installing the ansible-pylibssh package.
      - I(auto) will use ansible-pylibssh if that package is installed, otherwise will fallback to paramiko.
    default: auto
    choices: ["libssh", "paramiko", "auto"]
    type: string
    env:
        - name: ANSIBLE_NETWORK_CLI_SSH_TYPE
    ini:
        - section: persistent_connection
          key: ssh_type
    vars:
    - name: ansible_network_cli_ssh_type
  host_key_checking:
    description: 'Set this to "False" if you want to avoid host key checking by the underlying tools Ansible uses to connect to the host'
    type: boolean
    default: True
    env:
    - name: ANSIBLE_HOST_KEY_CHECKING
    - name: ANSIBLE_SSH_HOST_KEY_CHECKING
    ini:
    - section: defaults
      key: host_key_checking
    - section: persistent_connection
      key: host_key_checking
    vars:
    - name: ansible_host_key_checking
    - name: ansible_ssh_host_key_checking
  single_user_mode:
    type: boolean
    default: false
    version_added: 2.0.0
    description:
    - This option enables caching of data fetched from the target for re-use.
      The cache is invalidated when the target device enters configuration mode.
    - Applicable only for platforms where this has been implemented.
    env:
    - name: ANSIBLE_NETWORK_SINGLE_USER_MODE
    vars:
    - name: ansible_network_single_user_mode
"""

import fcntl
import getpass
import json
import logging
import os
import re
import signal
import socket
import tempfile
import time
import traceback

from binascii import hexlify
from functools import wraps
from io import BytesIO

from ansible.errors import AnsibleAuthenticationFailure, AnsibleConnectionFailure, AnsibleError
from ansible.module_utils.basic import missing_required_lib
from ansible.module_utils.common.text.converters import to_bytes, to_native, to_text
from ansible.module_utils.six.moves import cPickle
from ansible.playbook.play_context import PlayContext
from ansible.plugins.loader import cache_loader, cliconf_loader, connection_loader, terminal_loader
from ansible.utils.display import Display
from ansible.utils.path import makedirs_safe

from ansible_collections.ansible.netcommon.plugins.connection.libssh import HAS_PYLIBSSH
from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils import to_list
from ansible_collections.ansible.netcommon.plugins.plugin_utils.connection_base import (
    NetworkConnectionBase,
)


try:
    from scp import SCPClient

    HAS_SCP = True
except ImportError:
    HAS_SCP = False

# Import paramiko directly (network_cli's paramiko support is independent of ansible-core)
try:
    import paramiko

    from paramiko.ssh_exception import AuthenticationException, BadHostKeyException

    HAS_PARAMIKO = True
    PARAMIKO_IMPORT_ERR = None
except ImportError as err:
    HAS_PARAMIKO = False
    PARAMIKO_IMPORT_ERR = err
    paramiko = None
    AuthenticationException = None
    BadHostKeyException = None

# Import LooseVersion for paramiko version checks
try:
    from ansible.module_utils.compat.version import LooseVersion
except ImportError:
    # Fallback for older ansible versions
    from distutils.version import LooseVersion

display = Display()


# Paramiko host key authenticity message (prompt for user)
AUTHENTICITY_MSG = """
paramiko: The authenticity of host '%s' can't be established.
The %s key fingerprint is %s.
Are you sure you want to continue connecting (yes/no)?
"""
# One-line message when we cannot prompt (e.g. persistent connection)
AUTHENTICITY_ERR_MSG = (
    "paramiko: The authenticity of host '%s' can't be established. The %s key fingerprint is %s. "
    "Set host_key_auto_add=True to add the key and save it to known_hosts, or add the key manually."
)

# SSH Options Regex for parsing proxy commands
SETTINGS_REGEX = re.compile(r"(\w+)(?:\s*=\s*|\s+)(.+)")

# Base class for MissingHostKeyPolicy (paramiko may not be installed)
_MissingHostKeyPolicy = object
if paramiko:
    _MissingHostKeyPolicy = paramiko.MissingHostKeyPolicy


class _ParamikoHostKeyPolicy(_MissingHostKeyPolicy):
    """
    Host key policy for paramiko connections used by network_cli.

    Based on AutoAddPolicy in paramiko so we can determine when keys are added
    and also prompt for input.

    Policy for automatically adding the hostname and new host key to the
    local HostKeys object, and saving it.
    """

    def __init__(self, connection):
        self.connection = connection

    def missing_host_key(self, client, hostname, key):
        if all(
            (
                self.connection.get_option("host_key_checking"),
                not self.connection.get_option("host_key_auto_add"),
            )
        ):
            fingerprint = to_text(hexlify(key.get_fingerprint()), errors="surrogate_or_strict")
            ktype = key.get_name()

            if (
                self.connection.get_option("use_persistent_connections")
                or self.connection.force_persistence
            ):
                # don't print the prompt string since the user cannot respond
                # to the question anyway
                raise AnsibleError(AUTHENTICITY_ERR_MSG % (hostname, ktype, fingerprint))

            inp = to_text(
                display.prompt_until(
                    AUTHENTICITY_MSG % (hostname, ktype, fingerprint), private=False
                ),
                errors="surrogate_or_strict",
            )

            if inp not in ["yes", "y", ""]:
                raise AnsibleError("host connection rejected by user")

        key._added_by_ansible_this_time = True

        # existing implementation below:
        client._host_keys.add(hostname, key.get_name(), key)

        # host keys are actually saved in close() function below
        # in order to control ordering.


# Keep paramiko connection objects on a per host basis to avoid repeated attempts to reconnect
_PARAMIKO_SSH_CONNECTION_CACHE = {}
_PARAMIKO_SFTP_CONNECTION_CACHE = {}


class _ParamikoConnection:
    """
    Internal paramiko-based SSH connection class for network_cli.

    This class provides the paramiko SSH connection functionality that was
    previously loaded from ansible-core's paramiko connection plugin.
    It implements only the methods and attributes required by network_cli.

    Note: This class intentionally does NOT inherit from ConnectionBase to avoid
    issues with Ansible's plugin option system. Options are managed internally.

    .. deprecated:: 7.0.0
       paramiko support was removed from ansible-core in version 2.21.
       This compatibility layer is provided as a transitional measure.
       Please migrate to using ``ssh_type=libssh`` by installing ansible-pylibssh.
       This feature will be removed in a release after 2028-02-01.
    """

    transport = "network_cli_paramiko"
    _log_channel = None

    # Default option values for paramiko connection
    _PARAMIKO_DEFAULTS = {
        "remote_addr": None,
        "port": 22,
        "remote_user": None,
        "password": None,
        "private_key_file": None,
        "host_key_auto_add": True,
        "look_for_keys": True,
        "proxy_command": "",
        "pty": True,
        "record_host_keys": True,
        "host_key_checking": True,
        "use_rsa_sha2_algorithms": True,
        "banner_timeout": 30,
        "paramiko_timeout": 10,
        "use_persistent_connections": False,
    }

    def __init__(self, play_context, new_stdin, parent_connection=None):
        self._play_context = play_context
        self.ssh = None
        self._connected = False
        self.keyfile = os.path.expanduser("~/.ssh/known_hosts")
        # Store reference to parent connection for option lookups
        self._parent_connection = parent_connection
        # Attribute used by host key policy
        self.force_persistence = False
        # Plugin-related attributes expected by Ansible
        self._load_name = "network_cli_paramiko"
        self._original_path = __file__
        # Initialize options with defaults
        self._paramiko_options = dict(self._PARAMIKO_DEFAULTS)
        # Initialize from play_context where available
        if play_context:
            if hasattr(play_context, "remote_addr") and play_context.remote_addr:
                self._paramiko_options["remote_addr"] = play_context.remote_addr
            if hasattr(play_context, "remote_user") and play_context.remote_user:
                self._paramiko_options["remote_user"] = play_context.remote_user
            if hasattr(play_context, "port") and play_context.port:
                self._paramiko_options["port"] = play_context.port
            if hasattr(play_context, "password") and play_context.password:
                self._paramiko_options["password"] = play_context.password
            if hasattr(play_context, "private_key_file") and play_context.private_key_file:
                self._paramiko_options["private_key_file"] = play_context.private_key_file
            if hasattr(play_context, "timeout") and play_context.timeout:
                self._paramiko_options["paramiko_timeout"] = play_context.timeout

    def get_option(self, option, hostvars=None):
        """Get an option value from internal options, parent connection, or defaults.

        Priority order:
        1. Explicitly set options in _paramiko_options (via set_option/set_options)
        2. Parent connection's options (only for options we know about)
        3. Default values in _PARAMIKO_DEFAULTS

        Raises KeyError for unknown options to match expected plugin behavior.
        """
        # Only handle options that are relevant to paramiko
        # This ensures options like 'ssh_type' that are specific to network_cli
        # are not exposed through this connection
        if option not in self._PARAMIKO_DEFAULTS:
            raise KeyError(option)

        # First check if option was explicitly set on this connection
        if option in self._paramiko_options:
            return self._paramiko_options[option]

        # Then try to get from parent connection (network_cli) for shared options
        if self._parent_connection is not None:
            try:
                value = self._parent_connection.get_option(option)
                if value is not None:
                    return value
            except (KeyError, AttributeError):
                pass

        # Return default value
        return self._PARAMIKO_DEFAULTS[option]

    def set_option(self, option, value):
        """Set an option value."""
        # Store in our internal options
        self._paramiko_options[option] = value

    def set_options(self, task_keys=None, var_options=None, direct=None):
        """Set multiple options at once.

        This method is called by Ansible to configure the connection plugin.
        We only store options that are relevant to paramiko (i.e., in _PARAMIKO_DEFAULTS).
        Options like ssh_type that are specific to network_cli are not stored here.
        """
        # Only store options that are relevant to paramiko
        if direct:
            for key, value in direct.items():
                if key in self._PARAMIKO_DEFAULTS:
                    self._paramiko_options[key] = value

    def get_options(self, hostvars=None):
        """Get all options as a dictionary."""
        # Start with defaults
        options = dict(self._PARAMIKO_DEFAULTS)
        # Override with our stored options
        options.update(self._paramiko_options)
        return options

    def _cache_key(self):
        return "%s__%s__" % (self.get_option("remote_addr"), self.get_option("remote_user"))

    def _set_log_channel(self, name):
        """Mimic paramiko.SSHClient.set_log_channel"""
        self._log_channel = name

    def _parse_proxy_command(self, port=22):
        proxy_command = self.get_option("proxy_command") or None

        sock_kwarg = {}
        if proxy_command:
            replacers = {
                "%h": self.get_option("remote_addr"),
                "%p": port,
                "%r": self.get_option("remote_user"),
            }
            for find, replace in replacers.items():
                proxy_command = proxy_command.replace(find, str(replace))
            try:
                sock_kwarg = {"sock": paramiko.ProxyCommand(proxy_command)}
                display.vvv(
                    "CONFIGURE PROXY COMMAND FOR CONNECTION: %s" % proxy_command,
                    host=self.get_option("remote_addr"),
                )
            except AttributeError:
                display.warning(
                    "Paramiko ProxyCommand support unavailable. "
                    "Please upgrade to Paramiko 1.9.0 or newer. "
                    "Not using configured ProxyCommand"
                )

        return sock_kwarg

    def _connect(self):
        cache_key = self._cache_key()
        if cache_key in _PARAMIKO_SSH_CONNECTION_CACHE:
            self.ssh = _PARAMIKO_SSH_CONNECTION_CACHE[cache_key]
        else:
            self.ssh = _PARAMIKO_SSH_CONNECTION_CACHE[cache_key] = self._connect_uncached()

        self._connected = True
        return self

    def _connect_uncached(self):
        """Activates the connection object"""

        if not HAS_PARAMIKO:
            raise AnsibleError("paramiko is not installed: %s" % to_native(PARAMIKO_IMPORT_ERR))

        # Emit deprecation warning for paramiko usage
        display.deprecated(
            "The paramiko-based SSH transport for network_cli is deprecated. "
            "paramiko support is removed from ansible-core in version 2.21 and "
            "this compatibility layer in ansible.netcommon is provided as a "
            "transitional measure. Please migrate to using ssh_type=libssh by "
            "installing ansible-pylibssh. ",
            date="2028-02-01",
            collection_name="ansible.netcommon",
        )

        # Log paramiko availability for debugging
        display.vvvv(
            "PARAMIKO: direct import (version %s)" % paramiko.__version__,
            host=self.get_option("remote_addr"),
        )

        port = self.get_option("port") or 22
        display.vvv(
            "ESTABLISH PARAMIKO SSH CONNECTION FOR USER: %s on PORT %s TO %s"
            % (self.get_option("remote_user"), port, self.get_option("remote_addr")),
            host=self.get_option("remote_addr"),
        )

        ssh = paramiko.SSHClient()

        # Set pubkey and hostkey algorithms to disable
        paramiko_preferred_pubkeys = getattr(paramiko.Transport, "_preferred_pubkeys", ())
        paramiko_preferred_hostkeys = getattr(paramiko.Transport, "_preferred_keys", ())
        use_rsa_sha2_algorithms = self.get_option("use_rsa_sha2_algorithms")
        disabled_algorithms = {}
        if not use_rsa_sha2_algorithms:
            if paramiko_preferred_pubkeys:
                disabled_algorithms["pubkeys"] = tuple(
                    a for a in paramiko_preferred_pubkeys if "rsa-sha2" in a
                )
            if paramiko_preferred_hostkeys:
                disabled_algorithms["keys"] = tuple(
                    a for a in paramiko_preferred_hostkeys if "rsa-sha2" in a
                )

        # override paramiko's default logger name
        if self._log_channel is not None:
            ssh.set_log_channel(self._log_channel)

        self.keyfile = os.path.expanduser("~/.ssh/known_hosts")

        if self.get_option("host_key_checking"):
            for ssh_known_hosts in ("/etc/ssh/ssh_known_hosts", "/etc/openssh/ssh_known_hosts"):
                try:
                    ssh.load_system_host_keys(ssh_known_hosts)
                    break
                except OSError:
                    pass  # file was not found, but not required to function
            # Load user's known_hosts (same file we write to on close)
            if os.path.exists(self.keyfile):
                try:
                    ssh.load_system_host_keys(self.keyfile)
                except OSError:
                    pass
            ssh.load_system_host_keys()

        ssh_connect_kwargs = self._parse_proxy_command(port)

        ssh.set_missing_host_key_policy(_ParamikoHostKeyPolicy(self))

        conn_password = self.get_option("password")

        allow_agent = True
        if conn_password is not None:
            allow_agent = False

        try:
            key_filename = None
            if self.get_option("private_key_file"):
                key_filename = os.path.expanduser(self.get_option("private_key_file"))

            timeout = self.get_option("paramiko_timeout") or 10

            # paramiko 2.2 introduced auth_timeout parameter
            if LooseVersion(paramiko.__version__) >= LooseVersion("2.2.0"):
                ssh_connect_kwargs["auth_timeout"] = timeout

            # paramiko 1.15 introduced banner timeout parameter
            if LooseVersion(paramiko.__version__) >= LooseVersion("1.15.0"):
                ssh_connect_kwargs["banner_timeout"] = self.get_option("banner_timeout") or 30

            ssh.connect(
                self.get_option("remote_addr").lower(),
                username=self.get_option("remote_user"),
                allow_agent=allow_agent,
                look_for_keys=self.get_option("look_for_keys"),
                key_filename=key_filename,
                password=conn_password,
                timeout=timeout,
                port=port,
                disabled_algorithms=disabled_algorithms,
                **ssh_connect_kwargs,
            )
        except BadHostKeyException as e:
            raise AnsibleConnectionFailure("host key mismatch for %s" % e.hostname)
        except AuthenticationException as e:
            msg = "Failed to authenticate: {0}".format(to_text(e))
            raise AnsibleAuthenticationFailure(msg)
        except Exception as e:
            msg = to_text(e)
            if "PID check failed" in msg:
                raise AnsibleError(
                    "paramiko version issue, please upgrade paramiko on the machine running ansible"
                )
            elif "Private key file is encrypted" in msg:
                msg = "ssh %s@%s:%s : %s\nTo connect as a different user, use -u <username>." % (
                    self.get_option("remote_user"),
                    self.get_option("remote_addr"),
                    port,
                    msg,
                )
                raise AnsibleConnectionFailure(msg)
            else:
                raise AnsibleConnectionFailure(msg)

        return ssh

    def exec_command(self, cmd, in_data=None, sudoable=True):
        """Run a command on the remote host (not typically used by network_cli)"""
        raise NotImplementedError(
            "exec_command is not implemented for network_cli's internal paramiko connection"
        )

    def put_file(self, in_path, out_path):
        """Transfer a file from local to remote"""
        display.vvv("PUT %s TO %s" % (in_path, out_path), host=self.get_option("remote_addr"))

        if not os.path.exists(to_bytes(in_path, errors="surrogate_or_strict")):
            raise AnsibleError("file or module does not exist: %s" % in_path)

        try:
            self.sftp = self.ssh.open_sftp()
        except Exception as e:
            raise AnsibleError("failed to open a SFTP connection (%s)" % e)

        try:
            self.sftp.put(
                to_bytes(in_path, errors="surrogate_or_strict"),
                to_bytes(out_path, errors="surrogate_or_strict"),
            )
        except IOError:
            raise AnsibleError("failed to transfer file to %s" % out_path)

    def _connect_sftp(self):
        cache_key = "%s__%s__" % (self.get_option("remote_addr"), self.get_option("remote_user"))
        if cache_key in _PARAMIKO_SFTP_CONNECTION_CACHE:
            return _PARAMIKO_SFTP_CONNECTION_CACHE[cache_key]
        else:
            result = _PARAMIKO_SFTP_CONNECTION_CACHE[cache_key] = self._connect().ssh.open_sftp()
            return result

    def fetch_file(self, in_path, out_path):
        """Save a remote file to the specified path"""
        display.vvv("FETCH %s TO %s" % (in_path, out_path), host=self.get_option("remote_addr"))

        try:
            self.sftp = self._connect_sftp()
        except Exception as e:
            raise AnsibleError("failed to open a SFTP connection (%s)" % to_native(e))

        try:
            self.sftp.get(
                to_bytes(in_path, errors="surrogate_or_strict"),
                to_bytes(out_path, errors="surrogate_or_strict"),
            )
        except IOError:
            raise AnsibleError("failed to transfer file from %s" % in_path)

    def _any_keys_added(self):
        if self.ssh is None:
            return False
        for hostname, keys in self.ssh._host_keys.items():
            for keytype, key in keys.items():
                added_this_time = getattr(key, "_added_by_ansible_this_time", False)
                if added_this_time:
                    return True
        return False

    def _save_ssh_host_keys(self, filename):
        """
        Save SSH host keys - not using the paramiko save_ssh_host_keys function
        as we want to add new SSH keys at the bottom.
        """
        if not self._any_keys_added():
            return

        path = os.path.expanduser("~/.ssh")
        makedirs_safe(path)

        with open(filename, "w") as f:
            for hostname, keys in self.ssh._host_keys.items():
                for keytype, key in keys.items():
                    added_this_time = getattr(key, "_added_by_ansible_this_time", False)
                    if not added_this_time:
                        f.write("%s %s %s\n" % (hostname, keytype, key.get_base64()))

            for hostname, keys in self.ssh._host_keys.items():
                for keytype, key in keys.items():
                    added_this_time = getattr(key, "_added_by_ansible_this_time", False)
                    if added_this_time:
                        f.write("%s %s %s\n" % (hostname, keytype, key.get_base64()))

    def reset(self):
        if not self._connected:
            return
        self.close()
        self._connect()

    def close(self):
        """Terminate the connection"""
        cache_key = self._cache_key()
        _PARAMIKO_SSH_CONNECTION_CACHE.pop(cache_key, None)
        _PARAMIKO_SFTP_CONNECTION_CACHE.pop(cache_key, None)

        if hasattr(self, "sftp"):
            if self.sftp is not None:
                self.sftp.close()

        if (
            self.get_option("host_key_checking")
            and self.get_option("record_host_keys")
            and self._any_keys_added()
        ):
            # add any new SSH host keys
            lockfile = self.keyfile.replace("known_hosts", ".known_hosts.lock")
            dirname = os.path.dirname(self.keyfile)
            makedirs_safe(dirname)

            key_lock = open(lockfile, "w")
            try:
                fcntl.lockf(key_lock, fcntl.LOCK_EX)

                # just in case any were added recently
                self.ssh.load_system_host_keys()
                self.ssh._host_keys.update(self.ssh._system_host_keys)

                # gather information about the current key file
                key_dir = os.path.dirname(self.keyfile)
                if os.path.exists(self.keyfile):
                    key_stat = os.stat(self.keyfile)
                    mode = key_stat.st_mode
                    uid = key_stat.st_uid
                    gid = key_stat.st_gid
                else:
                    mode = 33188
                    uid = os.getuid()
                    gid = os.getgid()

                # Save the new keys to a temporary file and move it into place
                tmp_keyfile = tempfile.NamedTemporaryFile(dir=key_dir, delete=False)
                os.chmod(tmp_keyfile.name, mode & 0o7777)
                if hasattr(os, "chown"):
                    os.chown(tmp_keyfile.name, uid, gid)

                self._save_ssh_host_keys(tmp_keyfile.name)
                tmp_keyfile.close()

                os.rename(tmp_keyfile.name, self.keyfile)

            except Exception:
                # unable to save keys, including scenario when key was invalid
                traceback.print_exc()
            finally:
                fcntl.lockf(key_lock, fcntl.LOCK_UN)
                key_lock.close()

        if self.ssh:
            self.ssh.close()
        self._connected = False


def ensure_connect(func):
    @wraps(func)
    def wrapped(self, *args, **kwargs):
        if not self._connected:
            self._connect()
        self.update_cli_prompt_context()
        return func(self, *args, **kwargs)

    return wrapped


class AnsibleCmdRespRecv(Exception):
    pass


class Connection(NetworkConnectionBase):
    """CLI (shell) SSH connections on Paramiko"""

    transport = "ansible.netcommon.network_cli"
    has_pipelining = True

    def __init__(self, play_context, new_stdin, *args, **kwargs):
        super(Connection, self).__init__(play_context, new_stdin, *args, **kwargs)
        self._ssh_shell = None

        self._matched_prompt = None
        self._matched_cmd_prompt = None
        self._matched_pattern = None
        self._last_response = None
        self._history = list()
        self._command_response = None
        self._last_recv_window = None
        self._cache = None

        self._terminal = None
        self.cliconf = None

        # Managing prompt context
        self._check_prompt = False

        self._task_uuid = to_text(kwargs.get("task_uuid", ""))
        self._ssh_type_conn = None
        self._ssh_type = None

        self._single_user_mode = False

        if self._network_os:
            self._terminal = terminal_loader.get(self._network_os, self)
            if not self._terminal:
                raise AnsibleConnectionFailure("network os %s is not supported" % self._network_os)

            self.cliconf = cliconf_loader.get(self._network_os, self)
            if not self.cliconf:
                self.queue_message(
                    "vvvv",
                    "unable to load cliconf for network_os %s. Falling back to default"
                    % self._network_os,
                )
                self.cliconf = cliconf_loader.get("ansible.netcommon.default", self)
                if not self.cliconf:
                    raise AnsibleConnectionFailure("Couldn't load fallback cliconf plugin")

            self._sub_plugin = {
                "type": "cliconf",
                "name": self.cliconf._load_name,
                "obj": self.cliconf,
            }
            self.queue_message(
                "vvvv",
                "loaded cliconf plugin %s from path %s for network_os %s"
                % (
                    self.cliconf._load_name,
                    self.cliconf._original_path,
                    self._network_os,
                ),
            )
        else:
            raise AnsibleConnectionFailure(
                "Unable to automatically determine host network os. Please "
                "manually configure ansible_network_os value for this host"
            )
        self.queue_message("log", "network_os is set to %s" % self._network_os)

    @property
    def ssh_type(self):
        if self._ssh_type is None:
            self._ssh_type = self.get_option("ssh_type")
            self.queue_message("vvvv", "ssh type is set to %s" % self._ssh_type)
            # Support autodetection of supported library
            if self._ssh_type == "auto":
                self.queue_message("vvvv", "autodetecting ssh_type")
                if HAS_PYLIBSSH:
                    self._ssh_type = "libssh"
                else:
                    self.queue_message(
                        "warning",
                        "ansible-pylibssh not installed, falling back to paramiko",
                    )
                    self._ssh_type = "paramiko"
                self.queue_message("vvvv", "ssh type is now set to %s" % self._ssh_type)

        if self._ssh_type not in ["paramiko", "libssh"]:
            raise AnsibleConnectionFailure(
                "Invalid value '%s' set for ssh_type option."
                " Expected value is either 'libssh' or 'paramiko'" % self._ssh_type
            )

        return self._ssh_type

    @property
    def ssh_type_conn(self):
        if self._ssh_type_conn is None:
            if self.ssh_type == "libssh":
                # Use the libssh connection plugin from ansible.netcommon
                self._ssh_type_conn = connection_loader.get(
                    "ansible.netcommon.libssh", self._play_context, "/dev/null"
                )
            elif self.ssh_type == "paramiko":
                # Use the internal paramiko connection implementation
                # This removes the dependency on ansible-core's paramiko plugin
                self._ssh_type_conn = _ParamikoConnection(
                    self._play_context, "/dev/null", parent_connection=self
                )
            else:
                raise AnsibleConnectionFailure(
                    "Invalid value '%s' set for ssh_type option."
                    " Expected value is either 'libssh' or 'paramiko'" % self._ssh_type
                )

        return self._ssh_type_conn

    # To maintain backward compatibility
    @property
    def paramiko_conn(self):
        return self.ssh_type_conn

    def _get_log_channel(self):
        user = ""
        try:
            user = getpass.getuser()
        except KeyError:
            self.queue_message(
                "vv",
                "Current user (uid=%s) does not seem to exist on this system, leaving user empty."
                % os.getuid(),
            )
        name = "p=%s u=%s | " % (os.getpid(), user)
        name += "%s [%s]" % (self.ssh_type, self._play_context.remote_addr)
        return name

    @ensure_connect
    def get_prompt(self):
        """Returns the current prompt from the device"""
        return self._matched_prompt

    def exec_command(self, cmd, in_data=None, sudoable=True):
        # not accessible code alert can be taken out at around  01-01-2027,
        # when connection local is removed
        if self._ssh_shell:
            try:
                cmd = json.loads(to_text(cmd, errors="surrogate_or_strict"))
                kwargs = {"command": to_bytes(cmd["command"], errors="surrogate_or_strict")}
                for key in (
                    "prompt",
                    "answer",
                    "sendonly",
                    "newline",
                    "prompt_retry_check",
                ):
                    if cmd.get(key) is True or cmd.get(key) is False:
                        kwargs[key] = cmd[key]
                    elif cmd.get(key) is not None:
                        kwargs[key] = to_bytes(cmd[key], errors="surrogate_or_strict")
                return self.send(**kwargs)
            except ValueError:
                cmd = to_bytes(cmd, errors="surrogate_or_strict")
                return self.send(command=cmd)

        else:
            return super(Connection, self).exec_command(cmd, in_data, sudoable)

    def get_options(self, hostvars=None):
        options = super(Connection, self).get_options(hostvars=hostvars)
        options.update(self.ssh_type_conn.get_options(hostvars=hostvars))
        return options

    def set_options(self, task_keys=None, var_options=None, direct=None):
        super(Connection, self).set_options(
            task_keys=task_keys, var_options=var_options, direct=direct
        )
        self.ssh_type_conn.set_options(task_keys=task_keys, var_options=var_options, direct=direct)
        # Retain old look_for_keys behaviour, but only if not set
        if not any(
            [
                task_keys and ("look_for_keys" in task_keys),
                var_options and ("look_for_keys" in var_options),
                direct and ("look_for_keys" in direct),
            ]
        ):
            look_for_keys = not bool(
                self.get_option("password") and not self.get_option("private_key_file")
            )
            if not look_for_keys:
                # This actually can't be overridden yet without changes in ansible-core
                # TODO: Uncomment when appropriate
                # self.queue_message(
                #     "warning",
                #     "Option look_for_keys has been implicitly set to {0} because "
                #     "it was not set explicitly. This is retained to maintain "
                #     "backwards compatibility with the old behavior. This behavior "
                #     "will be removed in some release after 2024-01-01".format(
                #         look_for_keys
                #     ),
                # )
                self.ssh_type_conn.set_option("look_for_keys", look_for_keys)

    def update_play_context(self, pc_data):
        """Updates the play context information for the connection"""
        pc_data = to_bytes(pc_data)
        pc_data = cPickle.loads(pc_data, encoding="bytes")

        play_context = PlayContext()
        play_context.deserialize(pc_data)

        self.queue_message("vvvv", "updating play_context for connection")
        if self._play_context.become ^ play_context.become:
            if play_context.become is True:
                auth_pass = play_context.become_pass
                self._on_become(become_pass=auth_pass)
                self.queue_message("vvvv", "authorizing connection")
            else:
                self._terminal.on_unbecome()
                self.queue_message("vvvv", "deauthorizing connection")

        self._play_context = play_context
        if self._ssh_type_conn is not None:
            # TODO: This works, but is not really ideal. We would rather use
            #       set_options, but then we need more custom handling in that
            #       method.
            self._ssh_type_conn._play_context = play_context

        if hasattr(self, "reset_history"):
            self.reset_history()
        if hasattr(self, "disable_response_logging"):
            self.disable_response_logging()

        self._single_user_mode = self.get_option("single_user_mode")

    def set_check_prompt(self, task_uuid):
        self._check_prompt = task_uuid

    def update_cli_prompt_context(self):
        # set cli prompt context at the start of new task run only
        if self._check_prompt and self._task_uuid != self._check_prompt:
            self._task_uuid, self._check_prompt = self._check_prompt, False
            self.set_cli_prompt_context()

    def _connect(self):
        """
        Connects to the remote device and starts the terminal
        """
        if display.verbosity > 3:
            logging.getLogger(self.ssh_type).setLevel(logging.DEBUG)

        self.queue_message("vvvv", "invoked shell using ssh_type: %s" % self.ssh_type)

        self._single_user_mode = self.get_option("single_user_mode")

        if not self.connected:
            self.ssh_type_conn._set_log_channel(self._get_log_channel())
            self.ssh_type_conn.force_persistence = self.force_persistence

            command_timeout = self.get_option("persistent_command_timeout")
            max_pause = min(
                [
                    self.get_option("persistent_connect_timeout"),
                    command_timeout,
                ]
            )
            retries = self.get_option("network_cli_retries")
            total_pause = 0

            for attempt in range(retries + 1):
                try:
                    ssh = self.ssh_type_conn._connect()
                    break
                except AnsibleError:
                    raise
                except Exception as e:
                    pause = 2 ** (attempt + 1)
                    if attempt == retries or total_pause >= max_pause:
                        raise AnsibleConnectionFailure(to_text(e, errors="surrogate_or_strict"))
                    else:
                        msg = (
                            "network_cli_retry: attempt: %d, caught exception(%s), "
                            "pausing for %d seconds"
                            % (
                                attempt + 1,
                                to_text(e, errors="surrogate_or_strict"),
                                pause,
                            )
                        )

                        self.queue_message("vv", msg)
                        time.sleep(pause)
                        total_pause += pause
                        continue

            self.queue_message("vvvv", "ssh connection done, setting terminal")
            self._connected = True

            self._ssh_shell = ssh.ssh.invoke_shell()
            if self.ssh_type == "paramiko":
                self._ssh_shell.settimeout(command_timeout)

            self.queue_message(
                "vvvv",
                "loaded terminal plugin for network_os %s" % self._network_os,
            )

            terminal_initial_prompt = (
                self.get_option("terminal_initial_prompt") or self._terminal.terminal_initial_prompt
            )
            terminal_initial_answer = (
                self.get_option("terminal_initial_answer") or self._terminal.terminal_initial_answer
            )
            newline = (
                self.get_option("terminal_inital_prompt_newline")
                or self._terminal.terminal_inital_prompt_newline
            )
            check_all = self.get_option("terminal_initial_prompt_checkall") or False

            self.receive(
                prompts=terminal_initial_prompt,
                answer=terminal_initial_answer,
                newline=newline,
                check_all=check_all,
            )

            if self._play_context.become:
                self.queue_message("vvvv", "firing event: on_become")
                auth_pass = self._play_context.become_pass
                self._on_become(become_pass=auth_pass)

            self.queue_message("vvvv", "firing event: on_open_shell()")
            self._on_open_shell()

            self.queue_message("vvvv", "ssh connection has completed successfully")

        return self

    def _on_become(self, become_pass=None):
        """
        Wraps terminal.on_become() to handle
        privilege escalation failures based on user preference
        """
        on_become_error = self.get_option("become_errors")
        try:
            self._terminal.on_become(passwd=become_pass)
        except AnsibleConnectionFailure:
            if on_become_error == "ignore":
                pass
            elif on_become_error == "warn":
                self.queue_message("warning", "on_become: privilege escalation failed")
            else:
                raise

    def _on_open_shell(self):
        """
        Wraps terminal.on_open_shell() to handle
        terminal setting failures based on user preference
        """
        on_terminal_error = self.get_option("terminal_errors")
        try:
            self._terminal.on_open_shell()
        except AnsibleConnectionFailure:
            if on_terminal_error == "ignore":
                pass
            elif on_terminal_error == "warn":
                self.queue_message(
                    "warning",
                    "on_open_shell: failed to set terminal parameters",
                )
            else:
                raise

    def close(self):
        """
        Close the active connection to the device
        """
        # only close the connection if its connected.
        if self._connected:
            self.queue_message("debug", "closing ssh connection to device")
            if self._ssh_shell:
                self.queue_message("debug", "firing event: on_close_shell()")
                self._terminal.on_close_shell()
                self._ssh_shell.close()
                self._ssh_shell = None
                self.queue_message("debug", "cli session is now closed")

                self.ssh_type_conn.close()
                self._ssh_type_conn = None
                self.queue_message("debug", "ssh connection has been closed successfully")
        super(Connection, self).close()

    def _read_post_command_prompt_match(self):
        time.sleep(self.get_option("persistent_buffer_read_timeout"))
        data = self._ssh_shell.read_bulk_response()
        return data if data else None

    def receive_paramiko(
        self,
        command=None,
        prompts=None,
        answer=None,
        newline=True,
        prompt_retry_check=False,
        check_all=False,
        strip_prompt=True,
    ):
        recv = BytesIO()
        cache_socket_timeout = self.get_option("persistent_command_timeout")
        self._ssh_shell.settimeout(cache_socket_timeout)
        command_prompt_matched = False
        handled = False
        errored_response = None

        while True:
            if command_prompt_matched:
                try:
                    signal.signal(signal.SIGALRM, self._handle_buffer_read_timeout)
                    signal.setitimer(signal.ITIMER_REAL, self._buffer_read_timeout)
                    data = self._ssh_shell.recv(256)
                    signal.alarm(0)
                    self._log_messages("response-%s: %s" % (self._window_count + 1, data))
                    # if data is still received on channel it indicates the prompt string
                    # is wrongly matched in between response chunks, continue to read
                    # remaining response.
                    command_prompt_matched = False

                    # restart command_timeout timer
                    signal.signal(signal.SIGALRM, self._handle_command_timeout)
                    signal.alarm(self._command_timeout)

                except AnsibleCmdRespRecv:
                    # reset socket timeout to global timeout
                    return self._command_response
            else:
                data = self._ssh_shell.recv(256)
                self._log_messages("response-%s: %s" % (self._window_count + 1, data))
            # when a channel stream is closed, received data will be empty
            if not data:
                break

            recv.write(data)
            offset = recv.tell() - 256 if recv.tell() > 256 else 0
            recv.seek(offset)

            window = self._strip(recv.read())
            self._last_recv_window = window
            self._window_count += 1

            if prompts and not handled:
                handled = self._handle_prompt(window, prompts, answer, newline, False, check_all)
                self._matched_prompt_window = self._window_count
            elif (
                prompts
                and handled
                and prompt_retry_check
                and self._matched_prompt_window + 1 == self._window_count
            ):
                # check again even when handled, if same prompt repeats in next window
                # (like in the case of a wrong enable password, etc) indicates
                # value of answer is wrong, report this as error.
                if self._handle_prompt(
                    window,
                    prompts,
                    answer,
                    newline,
                    prompt_retry_check,
                    check_all,
                ):
                    raise AnsibleConnectionFailure(
                        "For matched prompt '%s', answer is not valid" % self._matched_cmd_prompt
                    )

            if self._find_error(window):
                # We can't exit here, as we need to drain the buffer in case
                # the error isn't fatal, and will be using the buffer again
                errored_response = window

            if self._find_prompt(window):
                if errored_response:
                    raise AnsibleConnectionFailure(errored_response)
                self._last_response = recv.getvalue()
                resp = self._strip(self._last_response)
                self._command_response = self._sanitize(resp, command, strip_prompt)
                if self._buffer_read_timeout == 0.0:
                    # reset socket timeout to global timeout
                    return self._command_response
                else:
                    command_prompt_matched = True

    def receive_libssh(
        self,
        command=None,
        prompts=None,
        answer=None,
        newline=True,
        prompt_retry_check=False,
        check_all=False,
        strip_prompt=True,
    ):
        self._command_response = resp = b""
        command_prompt_matched = False
        handled = False
        errored_response = None

        while True:
            if command_prompt_matched:
                data = self._read_post_command_prompt_match()
                if data:
                    command_prompt_matched = False
                else:
                    return self._command_response
            else:
                try:
                    data = self._ssh_shell.read_bulk_response()
                # TODO: Should be ConnectionError when pylibssh drops Python 2 support
                except OSError:
                    # Socket has closed
                    break

            if not data:
                continue
            self._last_recv_window = self._strip(data)
            resp += self._last_recv_window
            self._window_count += 1

            self._log_messages("response-%s: %s" % (self._window_count, data))

            if prompts and not handled:
                handled = self._handle_prompt(resp, prompts, answer, newline, False, check_all)
                self._matched_prompt_window = self._window_count
            elif (
                prompts
                and handled
                and prompt_retry_check
                and self._matched_prompt_window + 1 == self._window_count
            ):
                # check again even when handled, if same prompt repeats in next window
                # (like in the case of a wrong enable password, etc) indicates
                # value of answer is wrong, report this as error.
                if self._handle_prompt(
                    resp,
                    prompts,
                    answer,
                    newline,
                    prompt_retry_check,
                    check_all,
                ):
                    raise AnsibleConnectionFailure(
                        "For matched prompt '%s', answer is not valid" % self._matched_cmd_prompt
                    )

            if self._find_error(resp):
                # We can't exit here, as we need to drain the buffer in case
                # the error isn't fatal, and will be using the buffer again
                errored_response = resp

            if self._find_prompt(resp):
                if errored_response:
                    raise AnsibleConnectionFailure(errored_response)
                self._last_response = data
                self._command_response = self._sanitize(resp, command, strip_prompt)
                command_prompt_matched = True

    def receive(
        self,
        command=None,
        prompts=None,
        answer=None,
        newline=True,
        prompt_retry_check=False,
        check_all=False,
        strip_prompt=True,
    ):
        """
        Handles receiving of output from command
        """
        self._matched_prompt = None
        self._matched_cmd_prompt = None
        self._matched_prompt_window = 0
        self._window_count = 0

        # set terminal regex values for command prompt and errors in response
        self._terminal_stderr_re = self._get_terminal_std_re("terminal_stderr_re")
        self._terminal_stdout_re = self._get_terminal_std_re("terminal_stdout_re")

        self._command_timeout = self.get_option("persistent_command_timeout")
        self._validate_timeout_value(self._command_timeout, "persistent_command_timeout")

        self._buffer_read_timeout = self.get_option("persistent_buffer_read_timeout")
        self._validate_timeout_value(self._buffer_read_timeout, "persistent_buffer_read_timeout")

        self._log_messages("command: %s" % command)
        if self.ssh_type == "libssh":
            response = self.receive_libssh(
                command,
                prompts,
                answer,
                newline,
                prompt_retry_check,
                check_all,
                strip_prompt,
            )
        elif self.ssh_type == "paramiko":
            response = self.receive_paramiko(
                command,
                prompts,
                answer,
                newline,
                prompt_retry_check,
                check_all,
                strip_prompt,
            )

        return response

    @ensure_connect
    def send(
        self,
        command,
        prompt=None,
        answer=None,
        newline=True,
        sendonly=False,
        prompt_retry_check=False,
        check_all=False,
        strip_prompt=True,
    ):
        """
        Sends the command to the device in the opened shell
        """
        # try cache first
        if (not prompt) and (self._single_user_mode):
            out = self.get_cache().lookup(command)
            if out:
                self.queue_message("vvvv", "cache hit for command: %s" % command)
                return out

        if check_all:
            prompt_len = len(to_list(prompt))
            answer_len = len(to_list(answer))
            if prompt_len != answer_len:
                raise AnsibleConnectionFailure(
                    "Number of prompts (%s) is not same as that of answers (%s)"
                    % (prompt_len, answer_len)
                )
        try:
            cmd = b"%s\r" % command
            self._history.append(cmd)
            self._ssh_shell.sendall(cmd)
            self._log_messages("send command: %s" % cmd)
            if sendonly:
                return
            response = self.receive(
                command,
                prompt,
                answer,
                newline,
                prompt_retry_check,
                check_all,
                strip_prompt,
            )
            response = to_text(response, errors="surrogate_then_replace")

            if (not prompt) and (self._single_user_mode):
                if self._needs_cache_invalidation(command):
                    # invalidate the existing cache
                    if self.get_cache().keys():
                        self.queue_message("vvvv", "invalidating existing cache")
                        self.get_cache().invalidate()
                else:
                    # populate cache
                    self.queue_message("vvvv", "populating cache for command: %s" % command)
                    self.get_cache().populate(command, response)

            return response
        except (socket.timeout, AttributeError):
            self.queue_message("error", traceback.format_exc())
            raise AnsibleConnectionFailure(
                "timeout value %s seconds reached while trying to send command: %s"
                % (self._ssh_shell.gettimeout(), command.strip())
            )

    def _handle_buffer_read_timeout(self, signum, frame):
        self.queue_message(
            "vvvv",
            "Response received, triggered 'persistent_buffer_read_timeout' timer of %s seconds"
            % self.get_option("persistent_buffer_read_timeout"),
        )
        raise AnsibleCmdRespRecv()

    def _handle_command_timeout(self, signum, frame):
        msg = (
            "command timeout triggered, timeout value is %s secs.\nSee the timeout setting options in the Network Debug and Troubleshooting Guide."
            % self.get_option("persistent_command_timeout")
        )
        self.queue_message("log", msg)
        raise AnsibleConnectionFailure(msg)

    def _strip(self, data):
        """
        Removes ANSI codes from device response
        """
        for regex in self._terminal.ansi_re:
            data = regex.sub(b"", data)
        return data

    def _handle_prompt(
        self,
        resp,
        prompts,
        answer,
        newline,
        prompt_retry_check=False,
        check_all=False,
    ):
        """
        Matches the command prompt and responds

        :arg resp: Byte string containing the raw response from the remote
        :arg prompts: Sequence of byte strings that we consider prompts for input
        :arg answer: Sequence of Byte string to send back to the remote if we find a prompt.
                A carriage return is automatically appended to this string.
        :param prompt_retry_check: Bool value for trying to detect more prompts
        :param check_all: Bool value to indicate if all the values in prompt sequence should be matched or any one of
                          given prompt.
        :returns: True if a prompt was found in ``resp``. If check_all is True
                  will True only after all the prompt in the prompts list are matched. False otherwise.
        """
        single_prompt = False
        if not isinstance(prompts, list):
            prompts = [prompts]
            single_prompt = True
        if not isinstance(answer, list):
            answer = [answer]
        try:
            prompts_regex = [re.compile(to_bytes(r), re.I) for r in prompts]
        except re.error as exc:
            raise ConnectionError(
                "Failed to compile one or more terminal prompt regexes: %s.\n"
                "Prompts provided: %s" % (to_text(exc), prompts)
            )
        for index, regex in enumerate(prompts_regex):
            match = regex.search(resp)
            if match:
                self._matched_cmd_prompt = match.group()
                self._log_messages("matched command prompt: %s" % self._matched_cmd_prompt)

                # if prompt_retry_check is enabled to check if same prompt is
                # repeated don't send answer again.
                if not prompt_retry_check:
                    prompt_answer = to_bytes(answer[index] if len(answer) > index else answer[0])
                    if newline:
                        prompt_answer += b"\r"
                    self._ssh_shell.sendall(prompt_answer)
                    self._log_messages("matched command prompt answer: %s" % prompt_answer)
                if check_all and prompts and not single_prompt:
                    prompts.pop(0)
                    answer.pop(0)
                    return False
                return True
        return False

    def _sanitize(self, resp, command=None, strip_prompt=True):
        """
        Removes elements from the response before returning to the caller
        """
        cleaned = []
        for line in resp.splitlines():
            if command and line.strip() == command.strip():
                continue

            for prompt in self._matched_prompt.strip().splitlines():
                if prompt.strip() in line and strip_prompt:
                    break
            else:
                cleaned.append(line)

        return b"\n".join(cleaned).strip()

    def _find_error(self, response):
        """Searches the buffered response for a matching error condition"""
        for stderr_regex in self._terminal_stderr_re:
            if stderr_regex.search(response):
                self._log_messages(
                    "matched error regex (terminal_stderr_re) '%s' from response '%s'"
                    % (stderr_regex.pattern, response)
                )

                self._log_messages(
                    "matched stdout regex (terminal_stdout_re) '%s' from error response '%s'"
                    % (self._matched_pattern, response)
                )
                return True

        return False

    def _find_prompt(self, response):
        """Searches the buffered response for a matching command prompt"""
        for stdout_regex in self._terminal_stdout_re:
            match = stdout_regex.search(response)
            if match:
                self._matched_pattern = stdout_regex.pattern
                self._matched_prompt = match.group()
                self._log_messages(
                    "matched cli prompt '%s' with regex '%s' from response '%s'"
                    % (self._matched_prompt, self._matched_pattern, response)
                )
                return True

        return False

    def _validate_timeout_value(self, timeout, timer_name):
        if timeout < 0:
            raise AnsibleConnectionFailure(
                "'%s' timer value '%s' is invalid, value should be greater than or equal to zero."
                % (timer_name, timeout)
            )

    def transport_test(self, connect_timeout):
        """This method enables wait_for_connection to work.

        As it is used by wait_for_connection, it is called by that module's action plugin,
        which is on the controller process, which means that nothing done on this instance
        should impact the actual persistent connection... this check is for informational
        purposes only and should be properly cleaned up.
        """

        # Force a fresh connect if for some reason we have connected before.
        self.close()
        self._connect()
        self.close()

    def _get_terminal_std_re(self, option):
        terminal_std_option = self.get_option(option)
        terminal_std_re = []

        if terminal_std_option:
            for item in terminal_std_option:
                if "pattern" not in item:
                    raise AnsibleConnectionFailure(
                        "'pattern' is a required key for option '%s',"
                        " received option value is %s" % (option, item)
                    )
                pattern = rb"%s" % to_bytes(item["pattern"])
                flag = item.get("flags", 0)
                if flag:
                    flag = getattr(re, flag.split(".")[1])
                terminal_std_re.append(re.compile(pattern, flag))
        else:
            # To maintain backward compatibility
            terminal_std_re = getattr(self._terminal, option)

        return terminal_std_re

    def copy_file(self, source=None, destination=None, proto="scp", timeout=30):
        """Copies file over scp/sftp to remote device

        :param source: Source file path
        :param destination: Destination file path on remote device
        :param proto: Protocol to be used for file transfer,
                      supported protocol: scp and sftp
        :param timeout: Specifies the wait time to receive response from
                        remote host before triggering timeout exception
        :return: None
        """
        if self.ssh_type == "libssh":
            self.ssh_type_conn.put_file(source, destination, proto=proto)
        elif self.ssh_type == "paramiko":
            ssh = self.ssh_type_conn._connect_uncached()
            if proto == "scp":
                if not HAS_SCP:
                    raise AnsibleError(missing_required_lib("scp"))
                with SCPClient(ssh.get_transport(), socket_timeout=timeout) as scp:
                    scp.put(source, destination)
            elif proto == "sftp":
                with ssh.open_sftp() as sftp:
                    sftp.put(source, destination)
            else:
                raise AnsibleError("Do not know how to do transfer file over protocol %s" % proto)
        else:
            raise AnsibleError("Do not know how to do SCP with ssh_type %s" % self.ssh_type)

    def get_file(self, source=None, destination=None, proto="scp", timeout=30):
        """Fetch file over scp/sftp from remote device
        :param source: Source file path
        :param destination: Destination file path
        :param proto: Protocol to be used for file transfer,
                      supported protocol: scp and sftp
        :param timeout: Specifies the wait time to receive response from
                        remote host before triggering timeout exception
        :return: None
        """
        if self.ssh_type == "libssh":
            self.ssh_type_conn._connect()
            self.ssh_type_conn.fetch_file(source, destination, proto=proto)
        elif self.ssh_type == "paramiko":
            ssh = self.ssh_type_conn._connect_uncached()
            if proto == "scp":
                if not HAS_SCP:
                    raise AnsibleError(missing_required_lib("scp"))
                try:
                    with SCPClient(ssh.get_transport(), socket_timeout=timeout) as scp:
                        scp.get(source, destination)
                except EOFError:
                    # This appears to be benign.
                    pass
            elif proto == "sftp":
                with ssh.open_sftp() as sftp:
                    sftp.get(source, destination)
            else:
                raise AnsibleError("Do not know how to do transfer file over protocol %s" % proto)
        else:
            raise AnsibleError("Do not know how to do SCP with ssh_type %s" % self.ssh_type)

    def get_cache(self):
        if not self._cache:
            # TO-DO: support jsonfile or other modes of caching with
            #        a configurable option
            self._cache = cache_loader.get("ansible.netcommon.memory")
        return self._cache

    def _is_in_config_mode(self):
        """
        Check if the target device is in config mode by comparing
        the current prompt with the platform's `terminal_config_prompt`.
        Returns False if `terminal_config_prompt` is not defined.

        :returns: A boolean indicating if the device is in config mode or not.
        """
        cfg_mode = False
        cur_prompt = to_text(self.get_prompt(), errors="surrogate_then_replace").strip()
        cfg_prompt = getattr(self._terminal, "terminal_config_prompt", None)
        if cfg_prompt and cfg_prompt.match(cur_prompt):
            cfg_mode = True
        return cfg_mode

    def _needs_cache_invalidation(self, command):
        """
        This method determines if it is necessary to invalidate
        the existing cache based on whether the device has entered
        configuration mode or if the last command sent to the device
        is potentially capable of making configuration changes.

        :param command: The last command sent to the target device.
        :returns: A boolean indicating if cache invalidation is required or not.
        """
        invalidate = False
        cfg_cmds = []
        try:
            # AnsiblePlugin base class in Ansible 2.9 does not have has_option() method.
            # TO-DO: use has_option() when we drop 2.9 support.
            cfg_cmds = self.cliconf.get_option("config_commands")
        except AttributeError:
            cfg_cmds = []
        if (self._is_in_config_mode()) or (to_text(command) in cfg_cmds):
            invalidate = True
        return invalidate
